"""inventory URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from product import views
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('products/', views.products, name='products'),
    path('orders/', views.orders, name='orders'),
    path('orders/add/', views.add_order, name='add'),
    path('orders/add/new/', views.add_orders, name='new'),
    path('orders/invoice/<str:pk>/', views.invoice, name='edit_product'),
    path('products/add_products/', views.add_products, name='add_products'),
    path('products/add_products/add/', views.add_product, name='add_product'),
    path('products/edit_product/<str:pk>/', views.edit_product, name='edit_product'),
    path('products/delete_product/<int:pk>/', views.delete_product, name='delete_product'),
    path('customers/', views.customers, name='customers'),
    path('export_csv', views.export_csv, name='export_csv'),
    path('customer_export_csv', views.customer_export_csv, name='customer_export_csv'),
    path('employee/', views.employee, name='employee'),
    path('admin/', admin.site.urls),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)