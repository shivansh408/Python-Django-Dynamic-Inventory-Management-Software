import datetime
import os
from django.contrib.auth.models import User
from django.db import models


# Create your models here.
class Product(models.Model):
    product_name = models.CharField(max_length=200, null=True)
    product_description = models.TextField(max_length=500, null=True)
    product_quantity = models.IntegerField("quantity", null=True)
    product_price = models.CharField(max_length=200, null=True)
    image = models.ImageField(null=True, blank=True, upload_to='images/')
    entry_date = models.DateTimeField('entry date', null=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.product_name


class Customer(models.Model):
    customer_name = models.CharField(max_length=200)
    phone = models.CharField(max_length=200)
    email = models.EmailField()
    order_no = models.CharField(max_length=300, null=True)
    remark = models.TextField(max_length=500, null=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)

    products = models.ForeignKey(
        Product,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
    )

    def __str__(self):
        return self.customer_name

class Order(models.Model):
    order_no = models.CharField(max_length=300, null=True)
    issue_date = models.DateTimeField('issue date', null=True)
    order_products = models.ManyToManyField(Product, verbose_name='list of products')
    order_amount = models.CharField(max_length=300, null=True)
    payment_status = models.PositiveIntegerField('payment status', null=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    customers = models.ForeignKey(
        Customer,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
    )

    def __str__(self):
        return self.order_no


userList = User.objects.values()