import csv
import os

from django.contrib import messages
from django.contrib.auth.models import User
from django.db import transaction
from django.db.models.functions import datetime
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.db.models import Sum
from django.db.models import F


# Create your views here.
from django.template.defaulttags import csrf_token

from product.models import Product, Customer, userList, Order


def index(request):
    tot = Order.objects.annotate(
        total_order=F('order_no')).latest('order_no')
    revenue = Order.objects.all().aggregate(Sum('order_amount'))['order_amount__sum'] or 0.00
    product_items = Product.objects.all().order_by("pk")
    return render(request, 'index.html', {
        "product_items": product_items, "tot": tot, "revenue": revenue
    })

def products(request):
    product_items = Product.objects.all().order_by("pk")
    return render(request, 'products.html', {
        "product_items": product_items
    })

def orders(request):
    e = Order.objects.all()
    return render(request, 'orders.html', {
        "e": e,
    })


def customers(request):
    customer_items = Customer.objects.all().order_by("pk")
    return render(request, 'customers.html', {
        "customer_items": customer_items
    })

def employee(request):
    employee_items = userList
    return render(request, 'employee.html', {
        "employee_items": employee_items
    })

def add_products(request):
    return render(request, 'add_product.html')

def invoice(request, pk):
    ord = Order.objects.get(id=pk)

    if request.method == "POST":
        ord.order_amount = request.POST['order_amount']
        ord.issue_date = request.POST['issue_date']

    context = {'ord': ord}
    return render(request, 'invoice.html', context)

def add_order(request):
    tot = Order.objects.annotate(
        total_price=F('order_no') + str(1)).latest('order_no')
    product_items = Product.objects.all().order_by("pk")
    return render(request, 'add_order.html', {
        "product_items": product_items, "tot": tot.total_price
    })

def export_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=Product' + str(datetime.datetime.now())+'.csv'
    writer = csv.writer(response)
    writer.writerow(['Product', 'Description', 'Added Date', 'Price', 'Quantity'])
    products = Product.objects.filter(owner=request.user)

    for product in products:
        writer.writerow([product.product_name, product.product_description, product.entry_date, product.product_price, product.product_quantity])

    return response

def customer_export_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=Customer' + str(datetime.datetime.now())+'.csv'
    writer = csv.writer(response)
    writer.writerow(['Customer', 'Address Line1', 'Address Line2', 'Location', 'Zipcode', 'Contact'])
    customers = Customer.objects.filter(owner=request.user)

    for customer in customers:
        writer.writerow([customer.customer_name, customer.add_line1, customer.add_line2, customer.city_name, customer.zipcode, customer.phone])

    return response

csrf_token
def add_product(request):
    product_name = request.POST['product_name']
    product_description = request.POST['product_description']
    product_quantity = request.POST['product_quantity']
    product_price = request.POST['product_price']
    images = request.FILES['img']
    entry_date = request.POST['entry_date']
    user = User.objects.get(username="admin12")
    created = Product(product_name=product_name, product_description=product_description, product_quantity=product_quantity, product_price=product_price, image=images, entry_date=entry_date, owner=user)
    created.save()
    lengths = Product.objects.all().count()
    return HttpResponseRedirect('/products/')


def add_orders(request):
    customer = request.POST['customer_name']
    phone = request.POST['phone']
    email = request.POST['email']
    order_no = request.POST['order_no']
    remark = request.POST['remark']
    user = User.objects.get(username="admin12")
    issue_date = request.POST['issue_date']
    total = request.POST['total_amount']
    payment_status = request.POST['status']
    product_name = request.POST.get('product')
    prod_names = [y.product_name for y in Product.objects.all()]
    prod_ids = []
    for y in prod_names:
        prod_ids.append(int(request.POST.get(y))) if request.POST.get(y) else print("not")
    print(prod_ids)

    with transaction.atomic():
        create = Customer(customer_name=customer, phone=phone, email=email, order_no=order_no, remark=remark, owner=user)
        crt = Order(order_no=order_no, issue_date=issue_date, order_amount=total, payment_status=payment_status, owner=user)
        create.save()
        crt.save()
        messages.success(request, 'New Order created successfully 👀.')
        for y in prod_ids:
            crt.order_products.add(Product.objects.get(id=y))

    return render(request, 'add_order.html', {
        "order": Order.objects.all()
    })


def edit_product(request, pk):
    prod = Product.objects.get(id=pk)

    if request.method == "POST":
        if len(request.FILES) != 0:
            if len(prod.image) > 0:
                os.remove(prod.image.path)
            prod.image = request.FILES['img']
        prod.product_name = request.POST['product_name']
        prod.product_description = request.POST['product_description']
        prod.product_quantity = request.POST['product_quantity']
        prod.product_price = request.POST['product_price']
        prod.entry_date = request.POST['entry_date']
        prod.user = User.objects.get(username="admin12")
        prod.save()
        return HttpResponseRedirect('/products/')

    context = {'prod':prod}
    return render(request, 'edit_product.html', context)

def delete_product(request, pk):
    Product.objects.get(id=pk).delete()
    return HttpResponseRedirect('/products/')